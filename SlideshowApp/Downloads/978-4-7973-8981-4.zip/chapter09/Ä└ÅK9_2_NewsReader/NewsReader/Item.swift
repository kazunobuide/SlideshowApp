//
//  Item.swift
//  NewsReader
//
//  Created by 高橋 京介 on 2016/10/23.
//  Copyright © 2016年 Kyosuke Takahashi. All rights reserved.
//

class Item {
    var title = ""
    var link = ""
}
