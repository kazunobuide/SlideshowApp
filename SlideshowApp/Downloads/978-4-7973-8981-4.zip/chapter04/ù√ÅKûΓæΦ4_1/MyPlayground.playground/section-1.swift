// 解決法①
var bodyTemp1 = 36.0
bodyTemp1 = 36.5

// 解決法②
var bodyTemp2:Double = 36
bodyTemp2 = 36.5

