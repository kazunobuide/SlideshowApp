func areaOfSquare(withSideLength length:Int) {
    print(length * length)
}
areaOfSquare(withSideLength: 3)
