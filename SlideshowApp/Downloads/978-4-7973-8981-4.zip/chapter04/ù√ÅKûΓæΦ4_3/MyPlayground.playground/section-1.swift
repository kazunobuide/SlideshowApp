var scoreDictionary = ["国語":95, "数学":70, "英語":80]
scoreDictionary["数学"] = 100
