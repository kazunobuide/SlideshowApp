var total = 0
let scoreArray = [95, 70, 80]
for score in scoreArray {
    total = total + score
}
print(total)
