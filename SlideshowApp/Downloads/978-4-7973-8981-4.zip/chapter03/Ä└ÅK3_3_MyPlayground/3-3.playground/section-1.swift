for n in 1...9 {
    print(3 * n)
}
