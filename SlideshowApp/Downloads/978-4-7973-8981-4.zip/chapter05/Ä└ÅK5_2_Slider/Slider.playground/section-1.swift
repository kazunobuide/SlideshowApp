// Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var slider = UISlider()
slider.value = 1.0
